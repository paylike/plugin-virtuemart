<?php

namespace Paylike\Exception;

/**
 * Class Unauthorized
 *
 * @package Paylike\Exception
 */
class Unauthorized extends ApiException
{

}
