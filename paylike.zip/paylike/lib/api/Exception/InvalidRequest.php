<?php

namespace Paylike\Exception;

/**
 * Class InvalidRequest
 *
 * @package Paylike\Exception
 */
class InvalidRequest extends ApiException
{

}
